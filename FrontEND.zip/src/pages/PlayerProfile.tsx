import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../components/ui/avatar';
import { Separator } from '../components/ui/separator';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { 
  ArrowLeft, 
  Calendar, 
  MapPin, 
  Target, 
  Activity, 
  Heart, 
  Award,
  User,
  Phone,
  Mail,
  Edit,
  Save,
  Camera,
  X,
  Plus,
  Minus,
  Footprints
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { toast } from 'sonner';
import { dataManagementService, Player as DataPlayer } from '../services/dataManagementService';

// Define our extended player interface
interface ExtendedPlayer extends DataPlayer {
  // Extended properties
  nickname?: string;
  secondaryPositions?: string[];
  dominantFoot?: string;
  birthDate?: Date | null;
  games?: number;
  yellowCards?: number;
  redCards?: number;
  shots?: number;
  shotsOnTarget?: number;
  passes?: number;
  passAccuracy?: number;
  foulsCommitted?: number;
  foulsReceived?: number;
  ballsLost?: number;
  ballsRecovered?: number;
  duelsWon?: number;
  duelsLost?: number;
  crosses?: number;
  saves?: number;
  photo?: string;
  shotMap?: { [key: string]: number };
  height?: number;
  weight?: number;
  number?: number;
  goals?: number;
  assists?: number;
  minutes?: number;
}

const PlayerProfile = () => {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  
  const [player, setPlayer] = useState<ExtendedPlayer | null>(null);
  const [loading, setLoading] = useState(true);

  const [isEditing, setIsEditing] = useState(false);
  const [editedPlayer, setEditedPlayer] = useState<ExtendedPlayer | null>(null);
  const [showPhotoUpload, setShowPhotoUpload] = useState(false);
  const [tempPhoto, setTempPhoto] = useState<string | null>(null);
  
  // Scoring areas state
  const [scoringAreas, setScoringAreas] = useState<number[][]>(Array(3).fill(null).map(() => Array(3).fill(0)));
  const [activeTab, setActiveTab] = useState<'offensive' | 'defensive' | 'scoring'>('offensive');

  // Mock performance data for the chart
  const performanceData = [
    { game: 'Match 1', goals: 1, assists: 0 },
    { game: 'Match 2', goals: 0, assists: 1 },
    { game: 'Match 3', goals: 2, assists: 1 },
    { game: 'Match 4', goals: 0, assists: 2 },
    { game: 'Match 5', goals: 1, assists: 0 },
  ];

  useEffect(() => {
    const loadPlayer = async () => {
      if (!id) {
        navigate('/players');
        return;
      }
      
      try {
        setLoading(true);
        const players = await dataManagementService.getPlayers();
        const foundPlayer = players.find(p => p.id === id);
        
        if (foundPlayer) {
          // Transform the player data to match our interface
          const transformedPlayer: ExtendedPlayer = {
            ...foundPlayer,
            number: foundPlayer.jersey_number || Math.floor(Math.random() * 99) + 1,
            nickname: (foundPlayer as any).nickname || '',
            secondaryPositions: (foundPlayer as any).secondaryPositions || [],
            dominantFoot: foundPlayer.preferred_foot || 'Right',
            birthDate: (foundPlayer as any).date_of_birth ? new Date((foundPlayer as any).date_of_birth) : null,
            games: (foundPlayer as any).games || 0,
            yellowCards: (foundPlayer as any).yellowCards || 0,
            redCards: (foundPlayer as any).redCards || 0,
            shots: (foundPlayer as any).shots || 0,
            shotsOnTarget: (foundPlayer as any).shotsOnTarget || 0,
            passes: (foundPlayer as any).passes || 0,
            passAccuracy: (foundPlayer as any).passAccuracy || 0,
            foulsCommitted: (foundPlayer as any).foulsCommitted || 0,
            foulsReceived: (foundPlayer as any).foulsReceived || 0,
            ballsLost: (foundPlayer as any).ballsLost || 0,
            ballsRecovered: (foundPlayer as any).ballsRecovered || 0,
            duelsWon: (foundPlayer as any).duelsWon || 0,
            duelsLost: (foundPlayer as any).duelsLost || 0,
            crosses: (foundPlayer as any).crosses || 0,
            saves: (foundPlayer as any).saves || 0,
            photo: foundPlayer.photo_url || '/placeholder.svg',
            shotMap: (foundPlayer as any).shotMap || { 
              'top-left': 0, 'top-center': 0, 'top-right': 0, 
              'middle-left': 0, 'middle-center': 0, 'middle-right': 0, 
              'bottom-left': 0, 'bottom-center': 0, 'bottom-right': 0 
            },
            height: foundPlayer.height || 0,
            weight: foundPlayer.weight || 0,
            goals: (foundPlayer as any).goals || 0,
            assists: (foundPlayer as any).assists || 0,
            minutes: (foundPlayer as any).minutes || 0
          };
          
          setPlayer(transformedPlayer);
          setEditedPlayer(transformedPlayer);
        } else {
          toast.error('Player not found');
          navigate('/players');
        }
      } catch (error) {
        console.error('Error loading player:', error);
        toast.error('Failed to load player data');
        navigate('/players');
      } finally {
        setLoading(false);
      }
    };
    
    loadPlayer();
    
    // Load scoring areas data from localStorage
    const savedScoringAreas = localStorage.getItem(`player_${id}_scoring_areas`);
    if (savedScoringAreas) {
      try {
        setScoringAreas(JSON.parse(savedScoringAreas));
      } catch (e) {
        console.error('Failed to parse scoring areas data', e);
      }
    }
    
    // Subscribe to player updates
    dataManagementService.setPlayersUpdateCallback((updatedPlayers) => {
      if (id) {
        const foundPlayer = updatedPlayers.find(p => p.id === id);
        if (foundPlayer) {
          // Transform the player data to match our interface
          const transformedPlayer: ExtendedPlayer = {
            ...foundPlayer,
            number: foundPlayer.jersey_number || Math.floor(Math.random() * 99) + 1,
            nickname: (foundPlayer as any).nickname || '',
            secondaryPositions: (foundPlayer as any).secondaryPositions || [],
            dominantFoot: foundPlayer.preferred_foot || 'Right',
            birthDate: (foundPlayer as any).date_of_birth ? new Date((foundPlayer as any).date_of_birth) : null,
            games: (foundPlayer as any).games || 0,
            yellowCards: (foundPlayer as any).yellowCards || 0,
            redCards: (foundPlayer as any).redCards || 0,
            shots: (foundPlayer as any).shots || 0,
            shotsOnTarget: (foundPlayer as any).shotsOnTarget || 0,
            passes: (foundPlayer as any).passes || 0,
            passAccuracy: (foundPlayer as any).passAccuracy || 0,
            foulsCommitted: (foundPlayer as any).foulsCommitted || 0,
            foulsReceived: (foundPlayer as any).foulsReceived || 0,
            ballsLost: (foundPlayer as any).ballsLost || 0,
            ballsRecovered: (foundPlayer as any).ballsRecovered || 0,
            duelsWon: (foundPlayer as any).duelsWon || 0,
            duelsLost: (foundPlayer as any).duelsLost || 0,
            crosses: (foundPlayer as any).crosses || 0,
            saves: (foundPlayer as any).saves || 0,
            photo: foundPlayer.photo_url || '/placeholder.svg',
            shotMap: (foundPlayer as any).shotMap || { 
              'top-left': 0, 'top-center': 0, 'top-right': 0, 
              'middle-left': 0, 'middle-center': 0, 'middle-right': 0, 
              'bottom-left': 0, 'bottom-center': 0, 'bottom-right': 0 
            },
            height: foundPlayer.height || 0,
            weight: foundPlayer.weight || 0,
            goals: (foundPlayer as any).goals || 0,
            assists: (foundPlayer as any).assists || 0,
            minutes: (foundPlayer as any).minutes || 0
          };
          
          setPlayer(transformedPlayer);
          setEditedPlayer(transformedPlayer);
        }
      }
    });
    
    return () => {
      dataManagementService.setPlayersUpdateCallback(null);
    };
  }, [id, navigate]);

  const getPositionColor = (position: string) => {
    switch (position) {
      case 'DEL': return 'bg-red-100 text-red-800';
      case 'CEN': return 'bg-blue-100 text-blue-800';
      case 'DEF': return 'bg-green-100 text-green-800';
      case 'POR': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const handleEdit = () => {
    setIsEditing(true);
    setEditedPlayer(player);
  };

  const handleSave = async () => {
    if (!editedPlayer || !player || !player.id) {
      toast.error('Invalid player data');
      return;
    }

    const loadingToast = toast.loading('Updating player profile...');

    try {
      // Only update properties that exist on the DataPlayer interface
      const playerData: Partial<DataPlayer> = {
        name: editedPlayer.name,
        position: editedPlayer.position,
        jersey_number: editedPlayer.number ?? undefined,
        age: editedPlayer.age ?? undefined,
        nationality: editedPlayer.nationality,
        preferred_foot: editedPlayer.dominantFoot,
        height: editedPlayer.height ?? undefined,
        weight: editedPlayer.weight ?? undefined,
        photo_url: editedPlayer.photo,
        goals: editedPlayer.goals ?? undefined,
        assists: editedPlayer.assists ?? undefined
      };

      // Handle date_of_birth separately
      if (editedPlayer.birthDate) {
        (playerData as any).date_of_birth = editedPlayer.birthDate.toISOString().split('T')[0];
      }

      // Handle goals and assists
      playerData.goals = editedPlayer.goals;
      playerData.assists = editedPlayer.assists;

      console.log('Saving player data:', playerData);

      const updatedPlayer = await dataManagementService.updatePlayer(player.id, playerData);

      if (updatedPlayer) {
        const transformedPlayer: ExtendedPlayer = {
          ...updatedPlayer,
          number: updatedPlayer.jersey_number || editedPlayer.number,
          nickname: editedPlayer.nickname || '',
          secondaryPositions: editedPlayer.secondaryPositions || [],
          dominantFoot: updatedPlayer.preferred_foot || editedPlayer.dominantFoot || 'Right',
          birthDate: (updatedPlayer as any).date_of_birth ? new Date((updatedPlayer as any).date_of_birth) : editedPlayer.birthDate,
          games: (updatedPlayer as any).games || editedPlayer.games || 0,
          yellowCards: editedPlayer.yellowCards || 0,
          redCards: editedPlayer.redCards || 0,
          shots: editedPlayer.shots || 0,
          shotsOnTarget: editedPlayer.shotsOnTarget || 0,
          passes: editedPlayer.passes || 0,
          passAccuracy: editedPlayer.passAccuracy || 0,
          foulsCommitted: editedPlayer.foulsCommitted || 0,
          foulsReceived: editedPlayer.foulsReceived || 0,
          ballsLost: editedPlayer.ballsLost || 0,
          ballsRecovered: editedPlayer.ballsRecovered || 0,
          duelsWon: editedPlayer.duelsWon || 0,
          duelsLost: editedPlayer.duelsLost || 0,
          crosses: editedPlayer.crosses || 0,
          saves: editedPlayer.saves || 0,
          photo: updatedPlayer.photo_url || editedPlayer.photo || '/placeholder.svg',
          shotMap: editedPlayer.shotMap || { 
            'top-left': 0, 'top-center': 0, 'top-right': 0, 
            'middle-left': 0, 'middle-center': 0, 'middle-right': 0, 
            'bottom-left': 0, 'bottom-center': 0, 'bottom-right': 0 
          },
          height: updatedPlayer.height || editedPlayer.height || 0,
          weight: updatedPlayer.weight || editedPlayer.weight || 0,
          goals: (updatedPlayer as any).goals || editedPlayer.goals || 0,
          assists: (updatedPlayer as any).assists || editedPlayer.assists || 0,
          minutes: (updatedPlayer as any).minutes || editedPlayer.minutes || 0
        };

        setPlayer(transformedPlayer);
        setEditedPlayer(transformedPlayer);
        setIsEditing(false);

        if (tempPhoto) {
          const playerPhotos = JSON.parse(localStorage.getItem('player_photos') || '{}');
          playerPhotos[player.id] = tempPhoto;
          localStorage.setItem('player_photos', JSON.stringify(playerPhotos));
          setPlayer(prev => prev ? { ...prev, photo: tempPhoto } : null);
          setEditedPlayer(prev => prev ? { ...prev, photo: tempPhoto } : null);
          setTempPhoto(null);
        }

        toast.dismiss(loadingToast);
        toast.success('Player profile updated successfully!');
      } else {
        toast.dismiss(loadingToast);
        toast.error('Failed to update player profile - no response from server');
      }
    } catch (error: any) {
      console.error('Error updating player:', error);
      toast.dismiss(loadingToast);
      toast.error(error?.message || 'Failed to update player profile. Please check your connection and try again.');
    }
  };

  const handleCancel = () => {
    setIsEditing(false);
    setEditedPlayer(player);
    setTempPhoto(null);
  };

  const handleAreaClick = (row: number, col: number) => {
    if (!id) return;
    
    // Create a new array with updated value
    const newAreas = [...scoringAreas];
    
    // Ensure row exists
    if (!newAreas[row]) {
      newAreas[row] = [0, 0, 0];
    }
    
    // Ensure column exists
    if (col >= newAreas[row].length) {
      // Extend the row if needed
      while (newAreas[row].length <= col) {
        newAreas[row].push(0);
      }
    }
    
    // Increment the count for the clicked area
    newAreas[row][col] = (newAreas[row][col] || 0) + 1;
    
    // Update state
    setScoringAreas(newAreas);
    
    // Save to localStorage
    localStorage.setItem(`player_${id}_scoring_areas`, JSON.stringify(newAreas));
  };

  const resetScoringAreas = () => {
    if (!id) return;
    
    const resetAreas = Array(3).fill(null).map(() => Array(3).fill(0));
    setScoringAreas(resetAreas);
    localStorage.setItem(`player_${id}_scoring_areas`, JSON.stringify(resetAreas));
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <Button 
          variant="outline" 
          onClick={() => navigate('/players')}
          className="flex items-center gap-2"
        >
          <ArrowLeft size={16} />
          Back to Players
        </Button>
        {!isEditing ? (
          <Button onClick={handleEdit} className="flex items-center gap-2">
            <Edit size={16} />
            Edit Profile
          </Button>
        ) : (
          <div className="flex gap-2">
            <Button variant="outline" onClick={handleCancel}>
              Cancel
            </Button>
            <Button onClick={handleSave} className="flex items-center gap-2">
              <Save size={16} />
              Save Changes
            </Button>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Player Info Card */}
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <div className="flex flex-col items-center">
                <div className="relative">
                  <Avatar className="w-32 h-32 mb-4">
                    <AvatarImage src={tempPhoto || editedPlayer?.photo || '/placeholder.svg'} alt={editedPlayer?.name || 'Player'} />
                    <AvatarFallback className="text-2xl bg-blue-500 text-white">
                      {(editedPlayer?.name || '?').charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  {isEditing && (
                    <Button
                      onClick={() => document.getElementById('photo-upload')?.click()}
                      className="absolute bottom-4 right-0 w-8 h-8 p-0 rounded-full"
                      size="sm"
                    >
                      <Camera size={16} />
                    </Button>
                  )}
                </div>
                <input
                  id="photo-upload"
                  type="file"
                  accept="image/*"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      const reader = new FileReader();
                      reader.onload = (event) => {
                        const base64 = event.target?.result as string;
                        setTempPhoto(base64);
                        setEditedPlayer(prev => prev ? { ...prev, photo: base64 } : null);
                      };
                      reader.readAsDataURL(file);
                    }
                  }}
                  className="hidden"
                />
                {isEditing && editedPlayer ? (
                  <Input
                    value={editedPlayer.name || ''}
                    onChange={(e) => setEditedPlayer(prev => prev ? { ...prev, name: e.target.value } : null)}
                    className="text-2xl text-center font-bold"
                  />
                ) : (
                  <CardTitle className="text-2xl text-center">{player?.name || 'Loading...'}</CardTitle>
                )}
                {isEditing && editedPlayer ? (
                  <Input
                    value={editedPlayer.nickname || ''}
                    onChange={(e) => setEditedPlayer(prev => prev ? { ...prev, nickname: e.target.value } : null)}
                    placeholder="Nickname"
                    className="text-muted-foreground text-center"
                  />
                ) : (
                  player?.nickname && (
                    <p className="text-muted-foreground text-center">"{player.nickname}"</p>
                  )
                )}
                <div className="flex items-center gap-2 mt-2">
                  {isEditing && editedPlayer ? (
                    <Select 
                      value={editedPlayer.position || ''} 
                      onValueChange={(value) => setEditedPlayer(prev => prev ? { ...prev, position: value } : null)}
                    >
                      <SelectTrigger className={getPositionColor(editedPlayer.position || '')}>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="DEL">DEL</SelectItem>
                        <SelectItem value="CEN">CEN</SelectItem>
                        <SelectItem value="DEF">DEF</SelectItem>
                        <SelectItem value="POR">POR</SelectItem>
                      </SelectContent>
                    </Select>
                  ) : (
                    player && (
                      <Badge className={getPositionColor(player.position || '')}>
                        {player.position}
                      </Badge>
                    )
                  )}
                  {isEditing && editedPlayer ? (
                    <Input
                      type="number"
                      value={editedPlayer.number || ''}
                      onChange={(e) => setEditedPlayer(prev => prev ? { ...prev, number: parseInt(e.target.value) || 0 } : null)}
                      className="w-20"
                    />
                  ) : (
                    player && (
                      <Badge variant="outline">
                        #{player.number}
                      </Badge>
                    )
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {isEditing && editedPlayer ? (
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Age</Label>
                      <Input
                        type="number"
                        value={editedPlayer.age || ''}
                        onChange={(e) => setEditedPlayer(prev => prev ? { ...prev, age: parseInt(e.target.value) || 0 } : null)}
                      />
                    </div>
                    <div>
                      <Label>Nationality</Label>
                      <Input
                        value={editedPlayer.nationality || ''}
                        onChange={(e) => setEditedPlayer(prev => prev ? { ...prev, nationality: e.target.value } : null)}
                      />
                    </div>
                    <div>
                      <Label>Height (cm)</Label>
                      <Input
                        type="number"
                        value={editedPlayer.height || ''}
                        onChange={(e) => setEditedPlayer(prev => prev ? { ...prev, height: parseInt(e.target.value) || 0 } : null)}
                      />
                    </div>
                    <div>
                      <Label>Weight (kg)</Label>
                      <Input
                        type="number"
                        value={editedPlayer.weight || ''}
                        onChange={(e) => setEditedPlayer(prev => prev ? { ...prev, weight: parseInt(e.target.value) || 0 } : null)}
                      />
                    </div>
                    <div>
                      <Label>Dominant Foot</Label>
                      <Select 
                        value={editedPlayer.dominantFoot || ''} 
                        onValueChange={(value) => setEditedPlayer(prev => prev ? { ...prev, dominantFoot: value } : null)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select foot" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Right">Right</SelectItem>
                          <SelectItem value="Left">Left</SelectItem>
                          <SelectItem value="Both">Both</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                ) : (
                  player && (
                    <div className="grid grid-cols-2 gap-4">
                      <div className="flex items-center gap-2">
                        <Calendar size={16} className="text-muted-foreground" />
                        <span>{player.age} years</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <MapPin size={16} className="text-muted-foreground" />
                        <span>{player.nationality}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Activity size={16} className="text-muted-foreground" />
                        <span>{player.height || 0} cm</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Heart size={16} className="text-muted-foreground" />
                        <span>{player.weight || 0} kg</span>
                      </div>
                      <div className="flex items-center gap-2 col-span-2">
                        <Footprints size={16} className="text-muted-foreground" />
                        <span>{player.dominantFoot || 'Right'}</span>
                      </div>
                    </div>
                  )
                )}
                
                <Separator />
                
                {player && (
                  <div className="space-y-2">
                    <h3 className="font-semibold">Season Stats</h3>
                    <div className="grid grid-cols-3 gap-2 text-center">
                      <div className="bg-blue-50 p-2 rounded">
                        <div className="text-lg font-bold text-blue-600">{player.goals || 0}</div>
                        <div className="text-xs text-muted-foreground">Goals</div>
                      </div>
                      <div className="bg-green-50 p-2 rounded">
                        <div className="text-lg font-bold text-green-600">{player.assists || 0}</div>
                        <div className="text-xs text-muted-foreground">Assists</div>
                      </div>
                      <div className="bg-purple-50 p-2 rounded">
                        <div className="text-lg font-bold text-purple-600">{player.games || 0}</div>
                        <div className="text-xs text-muted-foreground">Games</div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Performance Stats */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Performance Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={performanceData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="game" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="goals" fill="#3b82f6" name="Goals" />
                    <Bar dataKey="assists" fill="#10b981" name="Assists" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <div className="space-y-6">
            {/* Tab Navigation */}
            <div className="flex border-b">
              <button
                className={`py-2 px-4 font-medium text-sm ${
                  activeTab === 'offensive'
                    ? 'border-b-2 border-blue-500 text-blue-600'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
                onClick={() => setActiveTab('offensive')}
              >
                Offensive Stats
              </button>
              <button
                className={`py-2 px-4 font-medium text-sm ${
                  activeTab === 'defensive'
                    ? 'border-b-2 border-blue-500 text-blue-600'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
                onClick={() => setActiveTab('defensive')}
              >
                Defensive Stats
              </button>
              <button
                className={`py-2 px-4 font-medium text-sm ${
                  activeTab === 'scoring'
                    ? 'border-b-2 border-blue-500 text-blue-600'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
                onClick={() => setActiveTab('scoring')}
              >
                Scoring Areas
              </button>
            </div>

            {/* Tab Content */}
            {activeTab === 'offensive' && (
              <Card>
                <CardHeader>
                  <CardTitle>Offensive Stats</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {isEditing && editedPlayer ? (
                    <>
                      <div className="flex justify-between items-center">
                        <Label>Goals</Label>
                        <Input
                          type="number"
                          value={editedPlayer.goals || ''}
                          onChange={(e) => setEditedPlayer(prev => prev ? { ...prev, goals: parseInt(e.target.value) || 0 } : null)}
                          className="w-20"
                        />
                      </div>
                      <div className="flex justify-between items-center">
                        <Label>Assists</Label>
                        <Input
                          type="number"
                          value={editedPlayer.assists || ''}
                          onChange={(e) => setEditedPlayer(prev => prev ? { ...prev, assists: parseInt(e.target.value) || 0 } : null)}
                          className="w-20"
                        />
                      </div>
                      <div className="flex justify-between items-center">
                        <Label>Shots</Label>
                        <Input
                          type="number"
                          value={editedPlayer.shots || ''}
                          onChange={(e) => setEditedPlayer(prev => prev ? { ...prev, shots: parseInt(e.target.value) || 0 } : null)}
                          className="w-20"
                        />
                      </div>
                      <div className="flex justify-between items-center">
                        <Label>Shots on Target</Label>
                        <Input
                          type="number"
                          value={editedPlayer.shotsOnTarget || ''}
                          onChange={(e) => setEditedPlayer(prev => prev ? { ...prev, shotsOnTarget: parseInt(e.target.value) || 0 } : null)}
                          className="w-20"
                        />
                      </div>
                      <div className="flex justify-between items-center">
                        <Label>Shot Accuracy</Label>
                        <span className="font-bold">
                          {(editedPlayer.shots || 0) > 0 && editedPlayer.shotsOnTarget ? 
                            Math.round((editedPlayer.shotsOnTarget / (editedPlayer.shots || 1)) * 100) : 0}%
                        </span>
                      </div>
                    </>
                  ) : (
                    player && (
                      <>
                        <div className="flex justify-between">
                          <span>Goals</span>
                          <span className="font-bold">{player.goals || 0}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Assists</span>
                          <span className="font-bold">{player.assists || 0}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Shots</span>
                          <span className="font-bold">{player.shots || 0}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Shots on Target</span>
                          <span className="font-bold">{player.shotsOnTarget || 0}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Shot Accuracy</span>
                          <span className="font-bold">
                            {player.shots && player.shots > 0 ? 
                              Math.round(((player.shotsOnTarget || 0) / player.shots) * 100) : 0}%
                          </span>
                        </div>
                      </>
                    )
                  )}
                </CardContent>
              </Card>
            )}

            {activeTab === 'defensive' && (
              <Card>
                <CardHeader>
                  <CardTitle>Defensive Stats</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {isEditing && editedPlayer ? (
                    <>
                      <div className="flex justify-between items-center">
                        <Label>Balls Recovered</Label>
                        <Input
                          type="number"
                          value={editedPlayer.ballsRecovered || ''}
                          onChange={(e) => setEditedPlayer(prev => prev ? { ...prev, ballsRecovered: parseInt(e.target.value) || 0 } : null)}
                          className="w-20"
                        />
                      </div>
                      <div className="flex justify-between items-center">
                        <Label>Duels Won</Label>
                        <Input
                          type="number"
                          value={editedPlayer.duelsWon || ''}
                          onChange={(e) => setEditedPlayer(prev => prev ? { ...prev, duelsWon: parseInt(e.target.value) || 0 } : null)}
                          className="w-20"
                        />
                      </div>
                      <div className="flex justify-between items-center">
                        <Label>Fouls Committed</Label>
                        <Input
                          type="number"
                          value={editedPlayer.foulsCommitted || ''}
                          onChange={(e) => setEditedPlayer(prev => prev ? { ...prev, foulsCommitted: parseInt(e.target.value) || 0 } : null)}
                          className="w-20"
                        />
                      </div>
                      <div className="flex justify-between items-center">
                        <Label>Yellow Cards</Label>
                        <Input
                          type="number"
                          value={editedPlayer.yellowCards || ''}
                          onChange={(e) => setEditedPlayer(prev => prev ? { ...prev, yellowCards: parseInt(e.target.value) || 0 } : null)}
                          className="w-20"
                        />
                      </div>
                      <div className="flex justify-between items-center">
                        <Label>Red Cards</Label>
                        <Input
                          type="number"
                          value={editedPlayer.redCards || ''}
                          onChange={(e) => setEditedPlayer(prev => prev ? { ...prev, redCards: parseInt(e.target.value) || 0 } : null)}
                          className="w-20"
                        />
                      </div>
                    </>
                  ) : (
                    player && (
                      <>
                        <div className="flex justify-between">
                          <span>Balls Recovered</span>
                          <span className="font-bold">{player.ballsRecovered || 0}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Duels Won</span>
                          <span className="font-bold">{player.duelsWon || 0}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Fouls Committed</span>
                          <span className="font-bold">{player.foulsCommitted || 0}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Yellow Cards</span>
                          <span className="font-bold">{player.yellowCards || 0}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Red Cards</span>
                          <span className="font-bold">{player.redCards || 0}</span>
                        </div>
                      </>
                    )
                  )}
                </CardContent>
              </Card>
            )}

            {activeTab === 'scoring' && (
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <CardTitle>Scoring Areas</CardTitle>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={resetScoringAreas}
                      className="text-xs"
                    >
                      Reset
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-col items-center">
                    <p className="text-sm text-gray-600 mb-4 text-center">
                      Tap on any area of the grid to record a goal from that position
                    </p>
                    
                    <div className="grid grid-cols-3 gap-2 w-48 h-48 bg-gray-100 p-4 rounded-lg border border-gray-200">
                      {[0, 1, 2].map((rowIndex) => 
                        [0, 1, 2].map((colIndex) => {
                          // Get current count for this area
                          const count = scoringAreas[rowIndex] ? scoringAreas[rowIndex][colIndex] || 0 : 0;
                          
                          return (
                            <button
                              key={`${rowIndex}-${colIndex}`}
                              className={`
                                w-full h-full flex items-center justify-center rounded-lg border-2 font-bold text-lg transition-all duration-200 relative cursor-pointer hover:scale-105 hover:shadow-md
                                ${count > 0 
                                  ? count > 3 
                                    ? 'bg-red-500 text-white border-red-600' 
                                    : count > 1 
                                      ? 'bg-orange-400 text-white border-orange-500' 
                                      : 'bg-yellow-300 text-gray-800 border-yellow-400'
                                  : 'bg-white text-gray-400 border-gray-300'}
                              `}
                              onClick={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                                handleAreaClick(rowIndex, colIndex);
                              }}
                            >
                              {count > 0 && (
                                <span className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold">
                                  {count}
                                </span>
                              )}
                              <div className="w-3 h-3 rounded-full bg-current opacity-20"></div>
                            </button>
                          );
                        })
                      )}
                    </div>
                    
                    <div className="mt-4 text-sm text-gray-600">
                      <p>Total Goals Recorded: {
                        scoringAreas.reduce((total, row) => 
                          total + row.reduce((rowTotal, cell) => rowTotal + cell, 0), 0
                        )
                      }</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PlayerProfile;